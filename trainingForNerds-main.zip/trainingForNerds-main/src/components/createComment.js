import React from 'react'
import { useParams } from 'react-router-dom'
import {addComment} from '../api'

export const CreateComment = () =>{
        const { id } = useParams()
        const HandleSubmit = (username, body) => {
            body = document.getElementsByName('body')[0].value;
            const newComment = {
                username: "jessjelly",
                body: body
            };
            addComment(id, newComment).then((res) => {
                window.location.reload(true)
            })
        }
        return (
            <section className='CommentSection'><form
                onSubmit={(e) => {
                    e.preventDefault()
                    HandleSubmit(e.target.value)
                }}>
                <textarea name="body" placeholder="Add Comment" onChange={(e) => (e.target.value)}></textarea>
                <button className="button">Submit</button>
            </form></section>
        );
    }

