
import { getAllReviews} from '../api';
import { useEffect, useState } from 'react';
import {useParams} from 'react-router-dom';
import {Link} from 'react-router-dom';

const ReviewMap = () =>{
    const [reviews, setReviews] = useState ([]);
    const {category} = useParams();
    useEffect(() => {
        const queries = {category}
        getAllReviews(queries).then((revList) => {
            setReviews(revList)
        })
    },[category])

    return(
        reviews.map((AllRev)=> {
            return(
            <Link to={`/single-review/${AllRev.review_id}`} key={AllRev.review_id}>
                <h1 >{AllRev.title}</h1>
                <p>{AllRev.review_body}</p>
            </Link>
            )
        })
    )
}

export default ReviewMap;