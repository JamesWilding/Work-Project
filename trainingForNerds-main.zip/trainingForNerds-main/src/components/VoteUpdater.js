import {React, useState, useEffect} from 'react'
import { updateVote } from '../api';


export function UpVote(props) {
    const [voteCounter, setVoteCounter] = useState(0);
    const { votes, reviewID} = props

    useEffect(() => {setVoteCounter(votes)}, [votes]);

    const handleClickUp = () => {
            updateVote(reviewID,1).then(() => {
                setVoteCounter(voteCounter+1)
    })

    }
    const handleClickDown = () => {
                updateVote(reviewID, -1).then(() => {
                    setVoteCounter(voteCounter-1)
                })
            }

    return (
        <div>
            <h2>Votes for dynamic {voteCounter}</h2>
            <button className='button' onClick={handleClickUp} >Up Vote</button>
            <button className='button' onClick={handleClickDown}>Down Vote</button>
        </div>
    );
}


