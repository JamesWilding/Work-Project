
import { getAllCategories } from '../api';
import { useEffect, useState } from 'react';
import {Link} from 'react-router-dom';


function CategoriesMap() {
    const [categories, setCategories] = useState ([]);

    useEffect(() => {
    getAllCategories().then((CatList) =>{
        setCategories(CatList)
        }) 
    },[])

    return(
        categories.map((CatTitle) => {
            return(
            <Link to={`/categories-map/${CatTitle.slug}`} key={CatTitle.slug}> 
            <li className="catName">{CatTitle.slug}</li>
            </Link>
            )
        }
    ))
}

export default CategoriesMap;