import {React} from 'react';


function NavBar () {
    return(
        <header className='navbar'>
            <div className="nav-heading">Board Game Review</div>
            <ul className="nav-menu">
                <li className="nav-item">
                    <a href="/" className="nav-link">Home  </a>
                    <a href="/categories-map" className="nav-link">categories  </a>
                    <a href="/review-map" className="nav-link">reviews</a>
                </li>
            </ul>
        </header>
    );
}



export default NavBar;