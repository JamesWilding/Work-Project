import { getSingleReview} from '../api';
import {React, useEffect, useState } from 'react';
import {useParams} from 'react-router-dom';
import {UpVote} from './VoteUpdater';
import {Comments} from './allComments';
import {CreateComment} from './createComment';


const SingleReview = () =>{
    const { id } = useParams()
    const [item, setItem] = useState ({})
    useEffect (() =>{
        getSingleReview (id).then((singleItem) => {
            setItem (singleItem);
        })
    },[])

        return(
            <div>
<h1>{item.title}</h1>
<br></br>
<h3>{item.owner}</h3>
<h3>{item.designer}</h3>
<br></br>
<h2>{item.review_body}</h2>
<br></br>
<h3>Category {item.category}</h3>
<h2>Votes for API {item.votes}</h2>
<div>
<UpVote votes={item.votes}reviewID={item.review_id}/>
</div> 
<CreateComment/>
<h2>Comments {item.comment_count}</h2>
<Comments reviewID={item.review_id}/>
            </div>
            )
    }

export default SingleReview;