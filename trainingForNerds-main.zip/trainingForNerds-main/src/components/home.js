import React, {Component} from 'react';

class Home extends Component {
    render() {
        return(
            <section className='page'>
                <div className='bumper'></div>
                <div className='main-container'>
                    <div className='content-container'>
                        <h1>Home test</h1>
                    </div>
                </div>
            </section>
        )
    }
}

export default Home