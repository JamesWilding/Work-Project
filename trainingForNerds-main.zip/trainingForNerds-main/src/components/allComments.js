import { getComment } from '../api';
import { useEffect, useState } from 'react';
import {useParams} from 'react-router-dom';
import { DeleteComment } from './deleteComment';

export const Comments = (props) =>{
    const [comments, setComments] = useState ([]);
    // const { reviewID } = props; - unable to use props as would not pull review id in use effect
    const { id } = useParams()
    let number = 0
        useEffect(() => {
            getComment(id).then((resComment) => {
                setComments(resComment)
        })
},[])

return (
    comments.map((comment) =>{
        number = comment.comment_id
        console.log(number)
        return(
        <div>
            <br></br>
            <p>{comment.author}</p>
            <p>{comment.body}</p>
            <DeleteComment Cid={number}/>
        </div>
        )
    }
)
)}
