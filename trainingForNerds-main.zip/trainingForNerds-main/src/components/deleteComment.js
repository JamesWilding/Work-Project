import { deleteComment } from '../api';
import {React} from 'react'

export const DeleteComment = (props) =>{
const {Cid} = props
console.log(typeof(Cid))
const deleteSelected = () => {
    deleteComment(Cid).then((res) => {deleteComment(Cid)
    window.location.reload(true)
})}

return(
    <button onClick={deleteSelected}>delete</button>
)
}