import "./App.css"
import React from "react";
import NavBar from './components/NavBar';
import CategoriesMap from "./components/categories";
import ReviewMap from "./components/allReview";
import Home from "./components/home";
import SingleReview from "./components/SingleReview";
import "./nav.css"
import {Route, Routes} from "react-router-dom"



const App = () => {
    return (
        <main className="main-body">
				<NavBar />
				<Routes>
					<Route path="/" element={<Home/>} />
					<Route path="/categories-map" element={<CategoriesMap/>}  />
					<Route path="/categories-map/:category" element={<ReviewMap/>} />
					<Route path="/review-map" element={<ReviewMap/>} />
					<Route path="/single-review/:id" element={<SingleReview/>} />
				</Routes>
        </main>
    )
}

export default App;