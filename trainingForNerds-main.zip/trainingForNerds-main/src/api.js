import axios from 'axios';

const mainApi = axios.create({
  baseURL: "https://nc-games-server-kp.herokuapp.com/api/" 
});

export const getAllCategories = () => {
  return mainApi.get("categories").then((res) => {return res.data.categories});
}

export const getAllReviews = (queries) => {
  return mainApi.get("reviews", {params : queries} ).then((res) => {return res.data.reviews});
}

export const getSingleReview = (review_id) => {
  return mainApi.get(`/reviews/${review_id}`).then((res) => {return res.data.review});
}

export const updateVote = (review_id, increase) => {
  return mainApi.patch(`/reviews/${review_id}`, { inc_votes: increase }).then((res) => {return res.data.comment})
}

export const getComment = (review_id) => {
  return mainApi.get(`/reviews/${review_id}/comments`).then((res) => {return res.data.comments})
}

export const addComment = (review_id, { username, body }) => {
  return mainApi.post(`/reviews/${review_id}/comments`, { username, body }).then((res) => {return res.data.comments})
}

export const deleteComment = (comment_id) => {
  return mainApi.delete(`/comments/${comment_id}`).then((res) => {return res.data.comments})
}